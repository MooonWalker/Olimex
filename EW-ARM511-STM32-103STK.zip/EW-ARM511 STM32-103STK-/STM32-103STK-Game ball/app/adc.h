// adc.h

#ifndef __STM32F_ADC
#define __STM32F_ADC

#include "arm_comm.h"

void ADCInit(void);
Int16U GetADCChanel(Int8U chanel);

#endif

