########################################################################
#
#                           RfVirtualCom.eww
#
# $Revision: 1.0 $
#
########################################################################

DESCRIPTION
===========
   This example project shows how to use the IAR Embedded Workbench
  for ARM to develop code for the Olimex STM32-103STK board.
   It implements wireless point to point USB CDC (Communication Device Class) 
  device and install it like a Virtual COM port. 
   The connection realize between device with Node A configuration and
  Node B configuration.
  
COMPATIBILITY
=============
   The RF USB CDC example project is compatible with, on the Olimex STM32-103STK
  evaluation board. By default, the project is configured to use the
  J-Link JTAG/SWD interface.

CONFIGURATION
=============

GETTING STARTED
===============

  1) Start the IAR Embedded Workbench for ARM.

  2) Select File->Open->Workspace...
     Open the following workspace:

     <installation-root>\arm\examples\ST\
     STM32F10x\OLIMEX-STM32F103-STK\RfVirtualCom\RfVirtualCom.eww

  3) Run the program.

     The RF USB CDC application is downloaded to the Embedded Flash memory
     on the evaluation board and executed.
