*** SUPPORT FILES FOR THE MOD-LCD3310 ***

These are generic support files with basic routines for interfacing the MOD-LCD3310 board using GPIO interface.
	
	The files provided are taken from the demo project for the LPC-P1227 and reconfigured to be used by STM32-103B by editing the section marked with:
	
/* TO IMPLEMENT YOUR VERSION OF THE DRIVER YOU'LL HAVE TO EDIT THIS SECTION ONLY */

...

/* END OF SECTION */

In order to use you should include library to your project.

Last edit:
2013.09.30
